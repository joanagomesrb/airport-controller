package sharedRegions;

import entities.*;
import java.util.Queue;
import java.util.Stack;

public class baggageCollectionPoint {

    bag[] collectionMat;


/*  PORTER 
    void carryItToAppropriateStore(bag)
 */

/*  PASSENGER 
    void goCollectABag(bag)
 */

}