package entities;

public class bag extends Thread{
    
    private char destination;
    private int id;

    public bag (char destination, int id)
    {
        this.destination = destination;
        this.id = id;

    }

}