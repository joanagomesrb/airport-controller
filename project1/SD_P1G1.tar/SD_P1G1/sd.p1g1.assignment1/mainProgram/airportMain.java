package mainProgram; 

import entities.*;
import sharedRegions.*;

/**
 * RepairShop is the main thread of the program
 */
public class airportMain {

	/**
	* Number of Customers 
	*/
	public static final int N = 30; 
	
	public void generateBags(){
        int[] array = {0,1,2,2};
        int val = (int) Math.floor(Math.random() * Math.floor(3));
        for(int i = 0; i < val; i++){

        }
	}
	
	//generatelostbag
}